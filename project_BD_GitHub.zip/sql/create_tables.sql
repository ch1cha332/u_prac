-- create_tables.sql: структура базы данных системы производственного планирования
-- СУБД: PostgreSQL. Выполнять в базе production_planning.

-- На случай повторного запуска: удаляем таблицы в обратном порядке (сначала зависимые)
DROP TABLE IF EXISTS schedule_item;
DROP TABLE IF EXISTS production_order;
DROP TABLE IF EXISTS operation;
DROP TABLE IF EXISTS product_type;
DROP TABLE IF EXISTS resource;

-- 1. Ресурс: сотрудник или станок
CREATE TABLE resource (
    resource_id   SERIAL PRIMARY KEY,
    name          VARCHAR(100) NOT NULL,
    category      VARCHAR(20)  NOT NULL,
    resource_type VARCHAR(50)  NOT NULL,
    CONSTRAINT uq_resource_name UNIQUE (name),
    CONSTRAINT chk_resource_category CHECK (category IN ('Сотрудник', 'Станок'))
);

-- 2. Вид изделия
CREATE TABLE product_type (
    product_type_id SERIAL PRIMARY KEY,
    name            VARCHAR(100)  NOT NULL,
    cost            NUMERIC(12,2) NOT NULL,
    CONSTRAINT uq_product_type_name UNIQUE (name),
    CONSTRAINT chk_product_type_cost CHECK (cost > 0)
);

-- 3. Операция техпроцесса (техпроцесс изделия = все его операции по порядку seq_num)
CREATE TABLE operation (
    operation_id           SERIAL PRIMARY KEY,
    product_type_id        INTEGER      NOT NULL,
    name                   VARCHAR(100) NOT NULL,
    seq_num                INTEGER      NOT NULL,
    duration_hours         INTEGER      NOT NULL,
    required_employee_type VARCHAR(50)  NOT NULL,
    required_machine_type  VARCHAR(50),            -- NULL = станок не нужен
    CONSTRAINT fk_operation_product_type
        FOREIGN KEY (product_type_id) REFERENCES product_type (product_type_id),
    CONSTRAINT uq_operation_product_seq UNIQUE (product_type_id, seq_num),
    CONSTRAINT chk_operation_seq_num CHECK (seq_num > 0),
    CONSTRAINT chk_operation_duration CHECK (duration_hours > 0)
);

-- 4. Заказ на производство ("order" в SQL зарезервировано, поэтому production_order)
CREATE TABLE production_order (
    order_id        SERIAL PRIMARY KEY,
    product_type_id INTEGER     NOT NULL,
    start_date      TIMESTAMP   NOT NULL,          -- начать не ранее
    deadline        TIMESTAMP   NOT NULL,          -- закончить не позднее
    status          VARCHAR(20) NOT NULL DEFAULT 'Не запланирован',
    CONSTRAINT fk_order_product_type
        FOREIGN KEY (product_type_id) REFERENCES product_type (product_type_id),
    CONSTRAINT chk_order_dates CHECK (deadline > start_date),
    CONSTRAINT chk_order_status CHECK (status IN ('Не запланирован', 'Запланирован'))
);

-- 5. Элемент расписания: одна операция одного заказа, выполненная сотрудником (и станком)
CREATE TABLE schedule_item (
    schedule_id  SERIAL PRIMARY KEY,
    order_id     INTEGER   NOT NULL,
    operation_id INTEGER   NOT NULL,
    employee_id  INTEGER   NOT NULL,               -- ссылка на resource (сотрудник)
    machine_id   INTEGER,                          -- ссылка на resource (станок), может быть NULL
    start_time   TIMESTAMP NOT NULL,
    end_time     TIMESTAMP NOT NULL,
    CONSTRAINT fk_schedule_order
        FOREIGN KEY (order_id) REFERENCES production_order (order_id) ON DELETE CASCADE,
    CONSTRAINT fk_schedule_operation
        FOREIGN KEY (operation_id) REFERENCES operation (operation_id),
    CONSTRAINT fk_schedule_employee
        FOREIGN KEY (employee_id) REFERENCES resource (resource_id),
    CONSTRAINT fk_schedule_machine
        FOREIGN KEY (machine_id) REFERENCES resource (resource_id),
    CONSTRAINT chk_schedule_time CHECK (end_time > start_time)
);
