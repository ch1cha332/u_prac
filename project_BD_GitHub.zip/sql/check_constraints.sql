-- 04_check_constraints.sql: проверка, что база защищает себя сама.
-- ОБЕ команды должны завершиться ОШИБКОЙ. Выполняйте их по одной.

-- Проверка 1: заказ с несуществующим видом изделия (изделия №99 нет) -> нарушение FOREIGN KEY
INSERT INTO production_order (product_type_id, start_date, deadline)
VALUES (99, '2026-04-06 08:00', '2026-04-07 16:00');

-- Проверка 2: операция с нулевой длительностью -> нарушение CHECK (duration_hours > 0)
INSERT INTO operation (product_type_id, name, seq_num, duration_hours, required_employee_type)
VALUES (1, 'Тестовая операция', 9, 0, 'Токарь');
