-- 03_queries.sql: шесть запросов для отчёта

-- Запрос 1. Все заказы, отсортированные по сроку «закончить не позднее»
SELECT order_id, product_type_id, start_date, deadline, status
FROM production_order
ORDER BY deadline;

-- Запрос 2. Операции одного техпроцесса (изделие №1) по порядку
SELECT seq_num, name, duration_hours, required_employee_type, required_machine_type
FROM operation
WHERE product_type_id = 1
ORDER BY seq_num;

-- Запрос 3. Все ресурсы заданного типа (токари)
SELECT resource_id, name, category, resource_type
FROM resource
WHERE resource_type = 'Токарь';

-- Запрос 4. Количество заказов по каждому виду изделий (GROUP BY)
SELECT product_type_id, COUNT(*) AS orders_count
FROM production_order
GROUP BY product_type_id
ORDER BY product_type_id;

-- Запрос 5. Заказы вместе с названием изделия (JOIN двух таблиц)
SELECT o.order_id, p.name AS product_name, o.start_date, o.deadline
FROM production_order o
JOIN product_type p ON p.product_type_id = o.product_type_id
ORDER BY o.order_id;

-- Запрос 6. Суммарная длительность техпроцесса каждого изделия (JOIN + GROUP BY + SUM)
SELECT p.name AS product_name, SUM(op.duration_hours) AS total_hours
FROM product_type p
JOIN operation op ON op.product_type_id = p.product_type_id
GROUP BY p.name
ORDER BY p.name;
