-- create_database.sql
-- Выполняется под суперпользователем postgres (в pgAdmin: Query Tool на базе postgres).
-- Пароль ниже ЗАМЕНИТЕ на свой и никому не показывайте; в GitHub этот файл с настоящим паролем не загружаем.

CREATE USER planner_user WITH PASSWORD 'ЗАМЕНИТЕ_НА_СВОЙ_ПАРОЛЬ';

CREATE DATABASE production_planning
    OWNER planner_user
    ENCODING 'UTF8';
